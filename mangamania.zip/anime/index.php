<?php 
    $sitepath="http://people.oregonstate.edu/~guzmannt/mangamania/anime/index.php";
    $pagetitle="Anime";
    include '../header.html'; 
?>

<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for animes...">

<!-- https://www.w3schools.com/howto/howto_js_filter_lists.asp -->
<ul id="myUL">
  <li><a href="http://www.anime-planet.com/anime/afro-samurai/videos" target="_blank">Afro Samurai</a></li>
  <li><a href="http://www.anime-planet.com/anime/akagami-no-shirayukihime/videos" target="_blank">Akagami no Shirayukihime</a></li>
  <li><a href="http://www.anime-planet.com/anime/black-cat/videos" target="_blank">Black Cat</a></li>
  <li><a href="http://www.anime-planet.com/anime/brothers-conflict/videos" target="_blank">Brothers Conflict</a></li>
  <li><a href="http://www.anime-planet.com/anime/bungou-stray-dogs/videos" target="_blank">Bungou Stray Dogs</a></li>
  <li><a href="http://www.anime-planet.com/anime/devil-may-cry/videos" target="_blank">Devil May Cry</a></li>
  <li><a href="http://www.anime-planet.com/anime/yona-of-the-dawn/videos" target="_blank">Yona of the Dawn</a></li>
  <li><a href="http://www.anime-planet.com/anime/clannad-after-story/videos" target="_blank">Clannad After Story</a></li>
  <li><a href="http://www.anime-planet.com/anime/hunter-x-hunter-2011/videos" target="_blank">Hunter x Hunter</a></li>
  <li><a href="http://www.anime-planet.com/anime/one-punch-man/videos" target="_blank">One-Punch Man</a></li>
  <li><a href="http://www.anime-planet.com/anime/great-teacher-onizuka/videos" target="_blank">Great Teacher Onizuka</a></li>
  <li><a href="http://www.anime-planet.com/anime/your-lie-in-april/videos" target="_blank">Your lie in April</a></li>
  <li><a href="http://www.anime-planet.com/anime/the-ancient-magus-bride/videos" target="_blank">The Ancient Magus' Bride</a></li>
  <li><a href="http://www.anime-planet.com/anime/descending-stories-shouwa-genroku-rakugo-shinjuu/videos" target="_blank">Descending Stories: Shouwa Genroku Rakugo Shinjuu</a></li>

</ul>


<?php include '../footer.html'; ?>