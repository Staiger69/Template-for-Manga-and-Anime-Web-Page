<!doctype html>
<head>
  <!-- php variables -->
  <?php
    $sitepath="http://people.oregonstate.edu/~guzmannt/mangamania/error.php";
    $pagetitle="Error Page";
    include 'header.html'; 
?>

</head>

<article class="white-bg">  
   <h1>
      ERROR! 
    </h1>
  <h2>
    We couldn't find that!
  </h2>
      <img src="img/hamster.png"
      alt="Hamster" 
      title="&copy; AzzureKaizer" 
      class="Hamster" /> 
    <h3>
      Our engineers are in their lunch break. They will fix the issue when they come back.
    </h3>
  <button type="button"><a href="http://people.oregonstate.edu/~guzmannt/mangamania/">Home Page</a></button>
  </p>

</article>  
  
<?php include 'footer.html'; ?>  
